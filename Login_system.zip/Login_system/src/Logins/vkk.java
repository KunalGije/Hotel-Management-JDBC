package Logins;
import Logins.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import Logins.Login_s;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;


public class vkk extends javax.swing.JFrame {
    PreparedStatement addChPS, fetChPS, searchChPS, modifyChPS, deleteChPS;
    Connection con;
    ResultSet fetChRes, searchChRes;
    
    public vkk() {
        this.setAlwaysOnTop(false);
        this.setResizable(false);
        this.setVisible(true);
         initComponents();
         this.setSize(700,650);
               setExtendedState(JFrame.MAXIMIZED_HORIZ);
               setVisible(true);
               this.dispose();
               setResizable(false);
               //this.dispose();
               setTitle("Hotel Management System");
     try {
            Class.forName("java.sql.Driver");
             con = DriverManager.getConnection("jdbc:mysql://localhost:3307/hotel_room", "root", "root");

        } catch (Exception ex) 
        {
            JOptionPane.showMessageDialog(null, ex);
        }
        fetchCh();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jModify = new javax.swing.JButton();
        jCustid = new javax.swing.JTextField();
        jDelete = new javax.swing.JButton();
        ph_no1 = new javax.swing.JTextField();
        jDisplay = new javax.swing.JButton();
        jReset = new javax.swing.JButton();
        jBack = new javax.swing.JButton();
        jCustId = new javax.swing.JLabel();
        jname = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jAddre = new javax.swing.JTextArea();
        jName = new javax.swing.JLabel();
        jAddress = new javax.swing.JLabel();
        icontact = new javax.swing.JLabel();
        jPhone_no = new javax.swing.JLabel();
        iname = new javax.swing.JLabel();
        jAdd = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        ch2 = new javax.swing.JLabel();
        ph_no22 = new javax.swing.JTextField();
        ph_no22val = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jModify.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jModify.setForeground(new java.awt.Color(255, 255, 255));
        jModify.setText("Modify");
        jModify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jModifyActionPerformed(evt);
            }
        });

        jCustid.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jCustid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCustidActionPerformed(evt);
            }
        });
        jCustid.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jCustidKeyReleased(evt);
            }
        });

        jDelete.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jDelete.setForeground(new java.awt.Color(255, 255, 255));
        jDelete.setText("Delete");
        jDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDeleteActionPerformed(evt);
            }
        });

        ph_no1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ph_no1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ph_no1ActionPerformed(evt);
            }
        });
        ph_no1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ph_no1KeyReleased(evt);
            }
        });

        jDisplay.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jDisplay.setForeground(new java.awt.Color(255, 255, 255));
        jDisplay.setText("Display");
        jDisplay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDisplayActionPerformed(evt);
            }
        });

        jReset.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jReset.setForeground(new java.awt.Color(255, 255, 255));
        jReset.setText("Reset");
        jReset.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jResetMouseClicked(evt);
            }
        });
        jReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jResetActionPerformed(evt);
            }
        });

        jBack.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jBack.setForeground(new java.awt.Color(255, 255, 255));
        jBack.setText("Back");
        jBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jBackMouseClicked(evt);
            }
        });
        jBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBackActionPerformed(evt);
            }
        });

        jCustId.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jCustId.setForeground(new java.awt.Color(255, 255, 255));
        jCustId.setText("Customer ID");

        jname.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jnameActionPerformed(evt);
            }
        });
        jname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jnameKeyReleased(evt);
            }
        });

        jAddre.setColumns(20);
        jAddre.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jAddre.setRows(5);
        jScrollPane2.setViewportView(jAddre);

        jName.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jName.setForeground(new java.awt.Color(255, 255, 255));
        jName.setText("Name");

        jAddress.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jAddress.setForeground(new java.awt.Color(255, 255, 255));
        jAddress.setText("Address");

        jPhone_no.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jPhone_no.setForeground(new java.awt.Color(255, 255, 255));
        jPhone_no.setText("Phone_no");

        iname.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        iname.setForeground(new java.awt.Color(51, 0, 51));

        jAdd.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jAdd.setForeground(new java.awt.Color(255, 255, 255));
        jAdd.setText("Add");
        jAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jAddMouseClicked(evt);
            }
        });
        jAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAddActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Customer Details");

        ch2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N

        ph_no22.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ph_no22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ph_no22ActionPerformed(evt);
            }
        });
        ph_no22.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ph_no22KeyReleased(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(127, 127, 127)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jName)
                            .addComponent(jCustId)
                            .addComponent(jAddress)
                            .addComponent(jPhone_no))
                        .addGap(109, 109, 109)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(iname, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jname, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jCustid, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 322, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(icontact, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(ph_no22val, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(ph_no1, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(18, 18, 18)
                                    .addComponent(ph_no22, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(ch2, javax.swing.GroupLayout.PREFERRED_SIZE, 473, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jModify)
                        .addGap(18, 18, 18)
                        .addComponent(jDelete)
                        .addGap(18, 18, 18)
                        .addComponent(jDisplay)
                        .addGap(18, 18, 18)
                        .addComponent(jReset)
                        .addGap(18, 18, 18)
                        .addComponent(jBack)))
                .addGap(0, 531, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(34, 34, 34)
                        .addComponent(ch2, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jname, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jName)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jCustId)
                        .addComponent(jCustid, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(iname, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jAddress))
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPhone_no)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(ph_no1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(ph_no22, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(ph_no22val, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(icontact, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 78, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jAdd)
                    .addComponent(jModify)
                    .addComponent(jDelete)
                    .addComponent(jDisplay)
                    .addComponent(jReset)
                    .addComponent(jBack))
                .addGap(189, 189, 189))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jCustidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCustidActionPerformed
     
    }//GEN-LAST:event_jCustidActionPerformed

    private void jCustidKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jCustidKeyReleased

        // TODO add your handling code here:
        String pattern="^[0-9]{3}$";
        Pattern patt=Pattern.compile(pattern);
           java.util.regex.Matcher match=patt.matcher(jCustid.getText());
        if(!match.matches())
        {
            ch2.setText("Enter 3 Digit customer ID ");
        }
        else
        {
            ch2.setText(null);
        }
    }//GEN-LAST:event_jCustidKeyReleased

    private void ph_no1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ph_no1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ph_no1ActionPerformed

    private void ph_no1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ph_no1KeyReleased
        // TODO add your handling code here:
        String pattern="^[0-9]{10}$";
        Pattern patt=Pattern.compile(pattern);
           java.util.regex.Matcher match=patt.matcher(ph_no1.getText());
        if(!match.matches())
        {
            icontact.setText("Enter 10 Digit Valid Phone no");
        }
        else
        {
            icontact.setText(null);
        }
    }//GEN-LAST:event_ph_no1KeyReleased

    private void jResetMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jResetMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jResetMouseClicked

    private void jResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jResetActionPerformed

        // TODO add your handling code here:
        jCustid.setText(null);
        jname.setText(null);
        jAddre.setText(null);
        ph_no1.setText(null);
        ph_no22.setText(null);
       
    }//GEN-LAST:event_jResetActionPerformed

    private void jBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jBackMouseClicked
        // TODO add your handling code here:
        this.dispose();
        Login_s a = new Login_s();
        a.setVisible(true);
    }//GEN-LAST:event_jBackMouseClicked

    private void jBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBackActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jBackActionPerformed

    private void jnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jnameActionPerformed

    private void jnameKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jnameKeyReleased
        String pattern="^[a-zA-Z]{3,30}[ ][a-zA-Z]{3,30}$";
        Pattern patt=Pattern.compile(pattern);
           java.util.regex.Matcher match=patt.matcher(jname.getText());
        if(!match.matches())
        {
            iname.setText("Enter Valid Name");
        }
        else
        {
            iname.setText(null);
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_jnameKeyReleased

    private void jAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jAddMouseClicked
        
    }//GEN-LAST:event_jAddMouseClicked

    private void jAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAddActionPerformed
        // TODO add your handling code here:
        Object cust_id = jCustid.getText();
        String cust_name = jname.getText();
        String addr = jAddre.getText();
        Object ph_no = ph_no1.getText();
        Object ph_no2=ph_no22.getText();
        
        try {
                            Statement sta = con.createStatement();
                            String query = "Insert into cust(cust_id,cust_name,addr) values('" + cust_id + "','" + cust_name + "','" + addr + "');";
                            sta.executeUpdate("Insert into ph_no values('"+ ph_no+"','"+cust_id+"')");
                            sta.executeUpdate("Insert into ph_no values("+ ph_no2+",'"+cust_id+"')");
                            addChPS = con.prepareStatement(query);
                            sta.executeUpdate(query);
                           // sta.executeUpdate("insert into ph_no values(" + ph_no + "," + cust_id + ");");
                            //sta.executeUpdate("insert into ph_no values(" + ph_no2 + "," + cust_id + ");");
                            //ResultSet rs = sta.executeQuery("select * from cust;");
                            JOptionPane.showMessageDialog(null, "SUCCESSFULLY DATA ADD !!!!!!");
                            //fetchCh();
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(null, ex);
                        }
              fetchCh();
        
    }//GEN-LAST:event_jAddActionPerformed

    private void jDisplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDisplayActionPerformed
        // TODO add your handling code here:\
         this.dispose();
        Display_1 a = new Display_1();
        a.setVisible(true);
    }//GEN-LAST:event_jDisplayActionPerformed

    private void ph_no22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ph_no22ActionPerformed
        // TODO add your handling code here:
             

    }//GEN-LAST:event_ph_no22ActionPerformed

    private void jDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDeleteActionPerformed
        // TODO add your handling code here:
        jAdd.setEnabled(false);
         jDisplay.setEnabled(false);
         jModify.setEnabled(false);
         jDelete.setEnabled(false);
         jReset.setEnabled(false);

        
        try{
          String query="delete from cust where cust_id=?";
          deleteChPS=con.prepareStatement(query);
          deleteChPS.setInt(1,Integer.parseInt(jCustid.getText()));
          deleteChPS.executeUpdate();
          JOptionPane.showMessageDialog(null,"Record Deleted Successfully !!");
          con.close(); 
        }catch(Exception ex)
        {
          JOptionPane.showMessageDialog(null, ex);
        }
         jDisplay.setEnabled(true);
   
    }//GEN-LAST:event_jDeleteActionPerformed

    private void ph_no22KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ph_no22KeyReleased
        // TODO add your handling code here:
           String pattern="^[0-9]{10}$";
        Pattern patt=Pattern.compile(pattern);
           java.util.regex.Matcher match=patt.matcher(ph_no22.getText());
        if(!match.matches())
        {
            ph_no22val.setText("Enter 10 Digit Valid Phone no");
        }
        else
        {
            ph_no22val.setText(null);
        }
    }//GEN-LAST:event_ph_no22KeyReleased

    private void jModifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jModifyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jModifyActionPerformed

    /**
     *
     * @param args
     */
    public static void main(String args[]) {
         java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new vkk().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ch2;
    private javax.swing.JLabel icontact;
    private javax.swing.JLabel iname;
    private javax.swing.JButton jAdd;
    private javax.swing.JTextArea jAddre;
    private javax.swing.JLabel jAddress;
    private javax.swing.JButton jBack;
    private javax.swing.JLabel jCustId;
    private javax.swing.JTextField jCustid;
    private javax.swing.JButton jDelete;
    private javax.swing.JButton jDisplay;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton jModify;
    private javax.swing.JLabel jName;
    private javax.swing.JLabel jPhone_no;
    private javax.swing.JButton jReset;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField jname;
    private javax.swing.JTextField ph_no1;
    private javax.swing.JTextField ph_no22;
    private javax.swing.JLabel ph_no22val;
    // End of variables declaration//GEN-END:variables

   
    private static class Matcher {

        public Matcher() {
        }
    }

public void fetchCh()
{
    try {
            String fet = "select cust_id,UCASE(cust_name) cust_name,addr,ph_no from cust";
            fetChPS = con.prepareStatement(fet);
            fetChRes = fetChPS.executeQuery();
          //  packTable.setModel(DBUtils.resultSetToTableModel(fetChRes));

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);

        }
}
  
    
}
