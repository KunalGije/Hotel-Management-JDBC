package Logins;
//import Logins.Login_s.Room.Display_Room_Data,*;
import javax.swing.JOptionPane;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import Logins.Login_s;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.regex.Pattern;
import javax.swing.JFrame;

public class Room extends javax.swing.JFrame {
    PreparedStatement addChPS, fetChPS, searchChPS, modifyChPS, deleteChPS;
    Connection con;
    ResultSet fetChRes, searchChRes;
    
 public Room() 
 {
        this.setAlwaysOnTop(false);
       this.setResizable(false); 
       this.setVisible(true);
         initComponents();
         this.setSize(700,650);
               setExtendedState(JFrame.MAXIMIZED_HORIZ);
               setVisible(true);
               setResizable(false);
               setTitle("Hotel Management System");
             try {
            Class.forName("java.sql.Driver");
             con = DriverManager.getConnection("jdbc:mysql://localhost:3307/hotel_room", "root", "root");

        } catch (Exception ex) 
        {
            JOptionPane.showMessageDialog(null, ex);
        }
        fetchCh();  
   
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jRoomNo = new javax.swing.JLabel();
        jRoomType = new javax.swing.JLabel();
        jRoomStatus = new javax.swing.JLabel();
        jRoomCharges = new javax.swing.JLabel();
        jComboBox2 = new javax.swing.JComboBox<>();
        jRoom_charges = new javax.swing.JTextField();
        jBtnModify = new javax.swing.JButton();
        jBtnDisplay = new javax.swing.JButton();
        jBtnBack = new javax.swing.JButton();
        jStatus = new javax.swing.JTextField();
        jadd = new javax.swing.JButton();
        jCharges_val = new javax.swing.JLabel();
        jRoom_no = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Room Details");

        jRoomNo.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jRoomNo.setForeground(new java.awt.Color(255, 255, 255));
        jRoomNo.setText("Room_no");

        jRoomType.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jRoomType.setForeground(new java.awt.Color(255, 255, 255));
        jRoomType.setText("Room Type");

        jRoomStatus.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jRoomStatus.setForeground(new java.awt.Color(255, 255, 255));
        jRoomStatus.setText("Room STATUS");

        jRoomCharges.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jRoomCharges.setForeground(new java.awt.Color(255, 255, 255));
        jRoomCharges.setText("Charges");

        jComboBox2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jComboBox2.setForeground(new java.awt.Color(255, 255, 255));
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "Non-AC", "" }));

        jRoom_charges.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jRoom_charges.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRoom_chargesActionPerformed(evt);
            }
        });
        jRoom_charges.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jRoom_chargesKeyPressed(evt);
            }
        });

        jBtnModify.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jBtnModify.setForeground(new java.awt.Color(255, 255, 255));
        jBtnModify.setText("MODIFY");

        jBtnDisplay.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jBtnDisplay.setForeground(new java.awt.Color(255, 255, 255));
        jBtnDisplay.setText("DISPLAY");
        jBtnDisplay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnDisplayActionPerformed(evt);
            }
        });

        jBtnBack.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jBtnBack.setForeground(new java.awt.Color(255, 255, 255));
        jBtnBack.setText("Back");
        jBtnBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jBtnBackMouseClicked(evt);
            }
        });
        jBtnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnBackActionPerformed(evt);
            }
        });

        jStatus.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jStatusActionPerformed(evt);
            }
        });

        jadd.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jadd.setForeground(new java.awt.Color(255, 255, 255));
        jadd.setText("ADD");
        jadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jaddActionPerformed(evt);
            }
        });

        jCharges_val.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jRoom_no.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jRoom_no.setEnabled(0);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jadd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(47, 47, 47)
                        .addComponent(jBtnModify, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(45, 45, 45)
                        .addComponent(jBtnDisplay)
                        .addGap(44, 44, 44)
                        .addComponent(jBtnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jRoomNo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jRoomCharges, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jRoomStatus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jRoomType, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(143, 143, 143)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jCharges_val, javax.swing.GroupLayout.PREFERRED_SIZE, 262, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jRoom_charges, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 160, Short.MAX_VALUE)
                                .addComponent(jStatus, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jComboBox2, javax.swing.GroupLayout.Alignment.LEADING, 0, 160, Short.MAX_VALUE))
                            .addComponent(jRoom_no, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(227, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(97, 97, 97)
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRoomNo)
                    .addComponent(jRoom_no, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRoomType)
                    .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(47, 47, 47)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jRoomStatus)
                    .addComponent(jStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jRoom_charges, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(jRoomCharges, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCharges_val, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBtnModify)
                    .addComponent(jBtnDisplay)
                    .addComponent(jBtnBack)
                    .addComponent(jadd, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(88, 88, 88))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBtnDisplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnDisplayActionPerformed
        // TODO add your handling code here:
    this.dispose();
    Display_Room_Data a = new Display_Room_Data();
         a.setVisible(true);
    }//GEN-LAST:event_jBtnDisplayActionPerformed
public void fetchCh() {
        try {
            String fet = "select room_no,type,status,charges from room";
            fetChPS = con.prepareStatement(fet);
            fetChRes = fetChPS.executeQuery();
            //packTable.setModel(DBUtils.resultSetToTableModel(fetChRes));

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex);

        }
}        
    private void jBtnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnBackActionPerformed
                 
        // TODO add your handling code here:
    }//GEN-LAST:event_jBtnBackActionPerformed

    private void jBtnBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jBtnBackMouseClicked
           this.dispose();
        Login_s a = new Login_s();
        a.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jBtnBackMouseClicked

    private void jStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jStatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jStatusActionPerformed

    private void jaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jaddActionPerformed
        // TODO add your handling code here:
        jRoom_no.setEnable(false);
        String room_no=(String) jRoom_no.getSelectedItem();
        Object type=jComboBox2.getSelectedItem();
        String status=jStatus.getText();
       String charges=jRoom_charges.getText();
        try
        {
                            Statement sta = con.createStatement();
                            String query = "Insert into room(type,status,charges) values ('" + type + "','" + status + "','" + charges + "');";
                            addChPS = con.prepareStatement(query);
                            sta.executeUpdate(query);
                            JOptionPane.showMessageDialog(null, "SUCCESSFULLY DATA ADD !!!!!!");
                              fetchCh();
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(null, ex);
                        }
               fetchCh();
       
    }//GEN-LAST:event_jaddActionPerformed

    private void jRoom_chargesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRoom_chargesActionPerformed
        // TODO add your handling code here:
         

    }//GEN-LAST:event_jRoom_chargesActionPerformed

    private void jRoom_chargesKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jRoom_chargesKeyPressed
        // TODO add your handling code here:
        String pattern="^[0-9]{4}$";
        Pattern patt=Pattern.compile(pattern);
           java.util.regex.Matcher match=patt.matcher(jRoom_charges.getText());
        if(!match.matches())
        {
            jCharges_val.setText("Enter charges in 4 digit");
        }
        else
        {
            jCharges_val.setText(null);
        }
    }//GEN-LAST:event_jRoom_chargesKeyPressed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Room().setVisible(true);
            }
        });
    }

  


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBtnBack;
    private javax.swing.JButton jBtnDisplay;
    private javax.swing.JButton jBtnModify;
    private javax.swing.JLabel jCharges_val;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jRoomCharges;
    private javax.swing.JLabel jRoomNo;
    private javax.swing.JLabel jRoomStatus;
    private javax.swing.JLabel jRoomType;
    private javax.swing.JTextField jRoom_charges;
    private javax.swing.JComboBox<String> jRoom_no;
    private javax.swing.JTextField jStatus;
    private javax.swing.JButton jadd;
    // End of variables declaration//GEN-END:variables

    
}
