package Logins;
import javax.swing.JOptionPane;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import Logins.Login_s;
import static com.sun.org.apache.xml.internal.security.c14n.Canonicalizer.register;
import static java.rmi.activation.Activatable.register;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;

public class Facilities extends javax.swing.JFrame {
    PreparedStatement addChPS, fetChPS, searchChPS, modifyChPS, deleteChPS;
    Connection con;
    ResultSet fetChRes, searchChRes;
    
    public Facilities() {
       this.setAlwaysOnTop(false);
        this.setResizable(false);
        this.setVisible(true);
         initComponents();
         this.setSize(700,650);
               setExtendedState(JFrame.MAXIMIZED_HORIZ);
               setVisible(true);
               setResizable(false);
               setTitle("Hotel Management System");
                try {
            Class.forName("java.sql.Driver");
             con = DriverManager.getConnection("jdbc:mysql://localhost:3307/hotel_room", "root", "root");

        } catch (Exception ex) 
        {
            JOptionPane.showMessageDialog(null, ex);
        }
        
    
   
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jCheckBoxMenuItem1 = new javax.swing.JCheckBoxMenuItem();
        jCheckBoxMenuItem2 = new javax.swing.JCheckBoxMenuItem();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jCharges = new javax.swing.JTextField();
        jAdd = new javax.swing.JButton();
        jModify = new javax.swing.JButton();
        jDelete = new javax.swing.JButton();
        jDisplay = new javax.swing.JButton();
        jReset = new javax.swing.JButton();
        jBack = new javax.swing.JButton();
        jFas_id = new javax.swing.JTextField();
        jfood = new javax.swing.JCheckBox();
        jLondary = new javax.swing.JCheckBox();
        jCombo_box1 = new javax.swing.JComboBox<>();

        jCheckBoxMenuItem1.setSelected(true);
        jCheckBoxMenuItem1.setText("jCheckBoxMenuItem1");

        jCheckBoxMenuItem2.setSelected(true);
        jCheckBoxMenuItem2.setText("jCheckBoxMenuItem2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(300, 300));
        setResizable(false);
        setSize(new java.awt.Dimension(0, 0));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Facilities");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Facilities ID");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Facility Name");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Charges");

        jAdd.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jAdd.setForeground(new java.awt.Color(255, 255, 255));
        jAdd.setText("ADD");
        jAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jAddMouseClicked(evt);
            }
        });
        jAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAddActionPerformed(evt);
            }
        });

        jModify.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jModify.setForeground(new java.awt.Color(255, 255, 255));
        jModify.setText("MODIFY");
        jModify.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jModifyMouseClicked(evt);
            }
        });
        jModify.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jModifyActionPerformed(evt);
            }
        });

        jDelete.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jDelete.setForeground(new java.awt.Color(255, 255, 255));
        jDelete.setText("DELETE");
        jDelete.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jDeleteMouseClicked(evt);
            }
        });
        jDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDeleteActionPerformed(evt);
            }
        });

        jDisplay.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jDisplay.setForeground(new java.awt.Color(255, 255, 255));
        jDisplay.setText("DISPLAY");
        jDisplay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jDisplayActionPerformed(evt);
            }
        });

        jReset.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jReset.setForeground(new java.awt.Color(255, 255, 255));
        jReset.setText("RESET");

        jBack.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jBack.setForeground(new java.awt.Color(255, 255, 255));
        jBack.setText("BACK");
        jBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jBackMouseClicked(evt);
            }
        });
        jBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBackActionPerformed(evt);
            }
        });

        jFas_id.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jFas_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFas_idActionPerformed(evt);
            }
        });

        jfood.setText("Food");

        jLondary.setText("Londary");

        jCombo_box1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Food", "Laundary" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jAdd)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jModify, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jDelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jDisplay))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(71, 71, 71)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jCharges, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jFas_id, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jfood)
                                .addGap(26, 26, 26)
                                .addComponent(jLondary, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jReset)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jBack))
                    .addComponent(jCombo_box1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 447, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel1)
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jfood)
                            .addComponent(jLondary, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jCombo_box1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(45, 45, 45)
                        .addComponent(jLabel4))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jFas_id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(108, 108, 108)
                        .addComponent(jCharges, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(85, 85, 85)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jAdd)
                    .addComponent(jModify)
                    .addComponent(jDelete)
                    .addComponent(jDisplay)
                    .addComponent(jReset)
                    .addComponent(jBack))
                .addContainerGap(105, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAddActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jAddActionPerformed

    private void jBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBackActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jBackActionPerformed

    private void jBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jBackMouseClicked
             this.dispose();
              Login_s a = new Login_s();
              a.setVisible(true);    
        // TODO add your handling code here:
    }//GEN-LAST:event_jBackMouseClicked

    private void jFas_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFas_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFas_idActionPerformed

    private void jAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jAddMouseClicked
        // TODO add your handling code here:
          String f_id = jFas_id.getText();
         Object f_name = jCombo_box1.getSelectedItem();
         
        String rate = jCharges.getText();
        try {
                            Statement sta = con.createStatement();
                            String query = "Insert into facilities(f_id,f_name,rate) values('" + f_id + "','" + f_name + "','" + rate + "');";
                            addChPS = con.prepareStatement(query);
                            sta.executeUpdate(query);
                            JOptionPane.showMessageDialog(null, "SUCCESSFULLY DATA ADD !!!!!!");
                            //fetchCh();
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(null, ex);
                        }

    }//GEN-LAST:event_jAddMouseClicked

    private void jDisplayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDisplayActionPerformed
        // TODO add your handling code here:
        this.dispose();
        fac_Display a= new fac_Display();
        a.setVisible(true);
    }//GEN-LAST:event_jDisplayActionPerformed

    private void jDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jDeleteActionPerformed
        jAdd.setEnabled(false);
         jDisplay.setEnabled(false);
         jModify.setEnabled(false);
         jDelete.setEnabled(false);
         jReset.setEnabled(false);

        
        try{
          String query="delete from facilities where f_id=?";
          deleteChPS=con.prepareStatement(query);
          deleteChPS.setInt(1,Integer.parseInt(jFas_id.getText()));
          deleteChPS.executeUpdate();
          JOptionPane.showMessageDialog(null,"Record Deleted Successfully !!");
          con.close(); 
        }catch(Exception ex)
        {
          JOptionPane.showMessageDialog(null, ex);
        }
         jDisplay.setEnabled(true);
    }//GEN-LAST:event_jDeleteActionPerformed

    private void jModifyMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jModifyMouseClicked
        // TODO add your handling code here:
    if ((jFas_id.getText()).length() > 0 ) {
             try{
                String searchChQuery = "select f_id,f_name,rate from facilities where f_id='" + jFas_id.getText() ;
                 searchChPS = con.prepareStatement(searchChQuery);
                searchChRes = searchChPS.executeQuery();
                if (searchChRes.next()) {
                    try {
                        String modifyChQuery = "update channel set f_id='" + jFas_id.getText() + "' where ch_id='" + jCombo_box1.getSelectedItem() + "'or ch_name='" + jCharges.getText() + "'";
                        modifyChPS = con.prepareStatement(modifyChQuery);
                        modifyChPS.execute();
                        //fetchCh();
                        JOptionPane.showMessageDialog(null, "SUCCESSFULLY MODIFIED !!!!!!!");
//                        AddPackages sF = new AddPackages();
//                        sF.setVisible(true);
//                        add(sF);
//                        sF.show();
                    } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(null, ex);
                    }
                } } catch (SQLException ex) {
                 Logger.getLogger(Facilities.class.getName()).log(Level.SEVERE, null, ex);
             }
            
             /*{
                    JOptionPane.showMessageDialog(null, "NO SUCH CHANNEL PRESENT IN DATABASE !!!!");
                }*/
        }
    else {
            JOptionPane.showMessageDialog(null, "PLEASE ENTER CHANNEL NO OR CHANNEL NAME!!!!");
        }
       
     
    }//GEN-LAST:event_jModifyMouseClicked

    private void jModifyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jModifyActionPerformed
        // TODO add your handling code here:
         
    }//GEN-LAST:event_jModifyActionPerformed

    private void jDeleteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jDeleteMouseClicked
        // TODO add your handling code here:
         

    }//GEN-LAST:event_jDeleteMouseClicked

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Facilities().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JButton jAdd;
    private javax.swing.JButton jBack;
    private javax.swing.JTextField jCharges;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem1;
    private javax.swing.JCheckBoxMenuItem jCheckBoxMenuItem2;
    private javax.swing.JComboBox<String> jCombo_box1;
    private javax.swing.JButton jDelete;
    private javax.swing.JButton jDisplay;
    private javax.swing.JTextField jFas_id;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JCheckBox jLondary;
    private javax.swing.JButton jModify;
    private javax.swing.JButton jReset;
    private javax.swing.JCheckBox jfood;
    // End of variables declaration//GEN-END:variables
}

