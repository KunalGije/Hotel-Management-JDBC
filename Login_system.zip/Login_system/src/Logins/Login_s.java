package Logins;
import Logins.vkk.*;
import javax.swing.JOptionPane;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import Logins.Login_s;
import Logins.Room;
import Logins.Facilities;
import Logins.Bills;
import java.lang.*;
import java.sql.Connection;
import javax.swing.JFrame;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Login_s extends javax.swing.JFrame
  {
    
       public Login_s(){
            try {
            Class.forName("java.sql.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel","root","root");
        } catch (Exception ex) {
           JOptionPane.showMessageDialog(null, ex);
        }
            
    this.setAlwaysOnTop(false);
        this.setResizable(false);
        this.setVisible(true);
         initComponents();
         this.setSize(700,650);
               setExtendedState(JFrame.MAXIMIZED_HORIZ);
               setVisible(true);
               this.dispose();
               setResizable(false);
               //this.dispose();
               setTitle("Hotel Management System");
   
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jBtnRoomD = new javax.swing.JButton();
        jbtnCustInfo = new javax.swing.JButton();
        jBtnFacilities = new javax.swing.JButton();
        jBtnBilling = new javax.swing.JButton();
        jBtnLogout = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setMinimumSize(new java.awt.Dimension(300, 300));
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Main Menu");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(260, 30, 290, 44);

        jBtnRoomD.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jBtnRoomD.setForeground(new java.awt.Color(255, 255, 255));
        jBtnRoomD.setText("Room Details");
        jBtnRoomD.setToolTipText("");
        jBtnRoomD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnRoomDActionPerformed(evt);
            }
        });
        getContentPane().add(jBtnRoomD);
        jBtnRoomD.setBounds(220, 200, 270, 40);

        jbtnCustInfo.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jbtnCustInfo.setForeground(new java.awt.Color(255, 255, 255));
        jbtnCustInfo.setText("Customer Information");
        jbtnCustInfo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jbtnCustInfoMouseClicked(evt);
            }
        });
        jbtnCustInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnCustInfoActionPerformed(evt);
            }
        });
        getContentPane().add(jbtnCustInfo);
        jbtnCustInfo.setBounds(220, 130, 270, 40);

        jBtnFacilities.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jBtnFacilities.setForeground(new java.awt.Color(255, 255, 255));
        jBtnFacilities.setText("Facilities");
        jBtnFacilities.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnFacilitiesActionPerformed(evt);
            }
        });
        getContentPane().add(jBtnFacilities);
        jBtnFacilities.setBounds(220, 270, 270, 40);

        jBtnBilling.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jBtnBilling.setForeground(new java.awt.Color(255, 255, 255));
        jBtnBilling.setText("Billings");
        jBtnBilling.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnBillingActionPerformed(evt);
            }
        });
        getContentPane().add(jBtnBilling);
        jBtnBilling.setBounds(220, 340, 270, 40);

        jBtnLogout.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jBtnLogout.setForeground(new java.awt.Color(255, 255, 255));
        jBtnLogout.setText("Logout");
        jBtnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnLogoutActionPerformed(evt);
            }
        });
        getContentPane().add(jBtnLogout);
        jBtnLogout.setBounds(220, 410, 270, 40);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnCustInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnCustInfoActionPerformed
        this.dispose();   
           vkk details = new vkk();
           details.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnCustInfoActionPerformed

    private void jBtnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnLogoutActionPerformed
            System.exit(0);
        // TODO add your handling code here:
    }//GEN-LAST:event_jBtnLogoutActionPerformed

    private void jbtnCustInfoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jbtnCustInfoMouseClicked
    this.dispose();   
           vkk details = new vkk();
           details.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jbtnCustInfoMouseClicked

    private void jBtnRoomDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnRoomDActionPerformed
        this.dispose();  
           Room room = new Room();
           room.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jBtnRoomDActionPerformed

    private void jBtnFacilitiesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnFacilitiesActionPerformed
        this.dispose();    
        Facilities fac = new Facilities();
          fac.setVisible(true);
        // TODO add your handling code here:
    }//GEN-LAST:event_jBtnFacilitiesActionPerformed

    private void jBtnBillingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnBillingActionPerformed
        this.dispose();  
        Bills bill = new Bills();
          bill.setVisible(true);
          
        // TODO add your handling code here:
    }//GEN-LAST:event_jBtnBillingActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login_s.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login_s.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login_s.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login_s.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login_s().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBtnBilling;
    private javax.swing.JButton jBtnFacilities;
    private javax.swing.JButton jBtnLogout;
    private javax.swing.JButton jBtnRoomD;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JButton jbtnCustInfo;
    // End of variables declaration//GEN-END:variables
private void SystemExit() {
        
    WindowEvent winCloseing = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
    }

    private void setresizeble(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
